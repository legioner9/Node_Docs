## Revealing Constructor Pattern

[![Паттерн Revealing Constructor - открытый конструктор](https://img.youtube.com/vi/leR5sXRkuJI/0.jpg)](https://www.youtube.com/watch?v=leR5sXRkuJI)
