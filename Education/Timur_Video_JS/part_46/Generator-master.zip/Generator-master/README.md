## Generators

[![Генераторы и асинхронные генераторы в JavaScript](https://img.youtube.com/vi/kvNm9D32s8s/0.jpg)](https://www.youtube.com/watch?v=kvNm9D32s8s)
