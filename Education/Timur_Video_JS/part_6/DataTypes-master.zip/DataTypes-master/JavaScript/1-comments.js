'use strict';

// Single comment

/*
  Multiline
  comments
*/
