[![Базовый синтаксис JavaScript](https://img.youtube.com/vi/xJn3k1f4BiM/0.jpg)](https://www.youtube.com/watch?v=xJn3k1f4BiM)
