## Directed graph and Query language

[![Графы и запросы к графовым структурам на JavaScript](https://img.youtube.com/vi/a0W0T8Yqw3s/0.jpg)](https://www.youtube.com/watch?v=a0W0T8Yqw3s)
