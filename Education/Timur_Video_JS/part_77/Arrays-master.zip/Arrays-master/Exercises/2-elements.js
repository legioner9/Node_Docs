'use strict';

const removeElements = (array, ...items) => {
  // Remove multiple items from array modifying original array
};

module.exports = { removeElements };
