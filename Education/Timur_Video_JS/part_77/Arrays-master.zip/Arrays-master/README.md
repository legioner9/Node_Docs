# Массивы в JavaScript (методы Array)

[![Массивы в JavaScript (методы Array)](https://img.youtube.com/vi/D1kfYBkX9FE/0.jpg)](https://www.youtube.com/watch?v=D1kfYBkX9FE)
