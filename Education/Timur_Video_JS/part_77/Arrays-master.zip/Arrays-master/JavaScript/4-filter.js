'use strict';

{
  const array = [1, 2, 3, 4];
  console.log(array.filter(x => !(x % 2)));
}
