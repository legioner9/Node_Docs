clear
node --trace-deopt --trace-opt 6-global.js
