'use strict';

const year = 1980;

module.exports = { year };
