'use strict';

const range = null;

module.exports = { range };
