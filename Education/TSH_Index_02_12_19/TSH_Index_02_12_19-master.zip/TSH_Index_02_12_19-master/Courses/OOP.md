# Объектно-ориентированное программирование

- [Have Objects Failed? Или что не так с ООП?](https://youtu.be/4yO5OS0vPSw)
- [Дженерики и обобщенное программирование](https://youtu.be/r6W2z3DQhoI)
  - Примеры кода: https://github.com/HowProgrammingWorks/Generics
- Принцип подстановки Барбары Лисков (готовится)
- Принцип единственной ответственности (готовится)
- [Шаблоны проектирования](Patterns.md)
- [Ассоциация, агрегация и композиция объектов](https://www.youtube.com/watch?v=tOIcBrzezK0)
  - Примеры кода: https://github.com/HowProgrammingWorks/Association
